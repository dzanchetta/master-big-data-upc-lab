package bdma.labos.hadoop.writer;

public class MyHBaseWriter_C_2 extends MyHBaseWriter {

	protected String nextKey() {
		return String.valueOf(super.data.get("type")+super.data.get("region")+Integer.toString(super.key));
	}
		
}
