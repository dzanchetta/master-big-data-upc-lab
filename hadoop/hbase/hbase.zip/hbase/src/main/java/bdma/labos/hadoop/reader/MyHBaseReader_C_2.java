package bdma.labos.hadoop.reader;

public class MyHBaseReader_C_2 extends MyHBaseReader {

	protected String scanStart() {
		return String.valueOf("type_30");
	}
	
	protected String scanStop() {
		return String.valueOf("type_31");
	}
		
}
