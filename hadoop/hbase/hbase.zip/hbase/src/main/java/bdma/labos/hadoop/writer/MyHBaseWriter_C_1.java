package bdma.labos.hadoop.writer;

import java.util.HashMap;

public class MyHBaseWriter_C_1 extends MyHBaseWriter {

	protected String toFamily(String attribute) {
		HashMap<String, String> name2family = new HashMap<String, String>();
		
		//put into the hashmap the attribute to each family at a time
		name2family.put("alc", "col_1");// Alcohol
		name2family.put("m_acid", "col_1");// Malic Acid
		name2family.put("ash", "col_2");// Ash
		name2family.put("alc_ash", "col_1");// Alcalinity of ash
		name2family.put("mgn", "col_1");// Magnesium
		name2family.put("t_phenols", "col_2");// Total phenols
		name2family.put("flav", "col_1");// Flavanoids
		name2family.put("nonflav_phenols", "col_1");// Nonflavanoid phenols
		name2family.put("proant", "col_2");// Proanthocyanins
		name2family.put("col", "col_1");// Color intensity
		name2family.put("hue", "col_1");// Hue
		name2family.put("od280/od315", "col_2");// OD280/OD315 of diluted wines
		name2family.put("proline", "col_3");// Proline
		name2family.put("type", "col_4"); //type
		name2family.put("region", "col_4"); //region
		
		if(name2family.containsKey(attribute))
			return name2family.get(attribute);
		
		return null;
	}
		
}
