package bdma.labos.hadoop.reader;

public class MyHBaseReader_C_1 extends MyHBaseReader {

	protected String[] scanFamilies() {
		String[] families = new String[2];
		families[0] = "col_3";
		families[1] = "col_4";
		return families;
	}
		
}
